const fs = require('fs');
const zhihu = require("./mylib/zhihu-new");

const logger = require('./mylib/logger');
const { program } = require('commander');

program
    .option('-zhihu, --zhihu <value>', '知乎主页网址', async function (urlParam, previousVal) {
        // 改了新的方式，不再用命令行传入参数了，直接从 txt 中读入网址
        const val = fs.readFileSync("./url.txt").toString().trim();
        logger.info(`你的知乎主页网址：${val}`);

        let prefix = 'http://localhost:85/zhihu'

        const name = await zhihu.checkName(val);
        if (name === false) {
            logger.info(`\n出现错误：未查询到知乎用户`);
            logger.info("出现错误：请使用笔记本打开“更新数据.bat”文件，并检查知乎主页网址");
        }
        else {
            logger.info(`查询到知乎用户：${name}`);
            try {
                await zhihu.start(val, 'xxx', function (sta) {
                    if (sta.code != 200) {
                        logger.error("数据拉取错误：", sta);
                    }
                    else {
                        logger.info("数据拉取中：", sta.name);
                    }
                });
            } catch (e) {
                logger.error("捕获严重错误：", e);
            }
            setTimeout(function () {
                logger.info("\n本软件已运行结束，可直接关闭");
            }, 1000);
        }
        
        setInterval(function () {

        }, 1000);
    });

program.parse(process.argv);


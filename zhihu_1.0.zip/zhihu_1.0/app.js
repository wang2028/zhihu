const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const url = require('url');
const path = require("path");
const zhihu = require("./data");
const axios = require('axios');
const _ = require('lodash');


var app = express();
app.use(express.json({limit: '50mb'}));
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));
app.use(bodyParser.urlencoded({ extended: false }));

app.use('/public', express.static(path.resolve("./public")));



app.get('/', function (req, res) {
  fs.readFile(path.resolve("./fixed", 'zhihu-local.html'), function (err, data) {
    if (err) {
      console.error("读取首页错误：" + err);
      return;
    }

    res.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8'
    });
    res.end(data);
  });
});

app.post("/api/data", function (req, res) {
  const keys = req.body;
  // console.log("keys:", keys);
  const zhihuData = _.cloneDeepWith(zhihu.data); // 用 lodash 的深拷贝，防止搜索关键词剔除数据时直接修改原数据
  if (keys.length === 0) {
    res.send(zhihuData.map(function (col, idx, arr) {
      const reducedCol = Object.assign({}, col);
      reducedCol.pages[0].content = reducedCol.pages[0].content.map(function (item) {
        const newItem = item;
        delete newItem.full;
        return newItem;
      })
      return reducedCol;
    }));
  }
  else {
    let resResult = {
      data: [],
      openedNames: [],
      searchResultNum: 0,
    };
    zhihuData.forEach(function (col, idx) {
      let newCol = Object.assign({}, col);
      delete newCol.pages;
      newCol.pages = [{
        content: [],
      }];
      col.pages[0].content.forEach(function (_item) {
        let item = _.cloneDeepWith(_item);
        let showStrKeyArr = [];
        let showFullStr = [];
        const canShow = keys.every(function (k) {
          let thisCan = false;
          if (item.author) {
            let keyIdx = item.author.toString().toLowerCase().indexOf(k)
            if (keyIdx >= 0) {
              showStrKeyArr.push("author");
              item.author = `${item.author.slice(0, keyIdx)}<span class='actived-key'>${k}</span>${item.author.slice(keyIdx + k.length)}`;
              thisCan = true;
            }
          }
          if (item.item) {
            let keyIdx = item.item.toString().toLowerCase().indexOf(k)
            if (keyIdx >= 0) {
              showStrKeyArr.push("item");
              item.item = `${item.item.slice(0, keyIdx)}<span class='actived-key'>${k}</span>${item.item.slice(keyIdx + k.length)}`;
              thisCan = true;
            }
          }
          if (item.summary) {
            let keyIdx = item.summary.toString().toLowerCase().indexOf(k)
            if (keyIdx >= 0) {
              showStrKeyArr.push("summary");
              showFullStr.push(`${item.summary.slice(0, keyIdx)}<span class='actived-key'>${k}</span>${item.summary.slice(keyIdx + k.length)}`);
              thisCan = true;
            }
          }
          if (item.full) {
            let keyIdx = item.full.toString().toLowerCase().indexOf(k);
            if (keyIdx >= 0) {
              showStrKeyArr.push("full");
              let cnt = 0;
              while (keyIdx >= 0 && cnt < 100) {
                showFullStr.push(`... ${item.full.slice(Math.max(0, keyIdx - 100), keyIdx).replace(/\</g, " ").replace(/\>/g, " ")}<span class='actived-key'>${k}</span>${item.full.slice(keyIdx + k.length, Math.min(keyIdx + k.length + 100, item.full.length)).replace(/\</g, " ").replace(/\>/g, " ")}...`)
                cnt++;
                keyIdx = item.full.toString().toLowerCase().indexOf(k, keyIdx + k.length + 1);
              }
              // console.log("k:", k);
              // console.log("showFullStr:", showFullStr);
              thisCan = true;
            }
          }
          
          return thisCan;
        });
        if (canShow) {
          item.summary = showFullStr.join("<br/>◉");
          
          delete item.full;
          newCol.pages[0].content.push(item);
        }
      });
      if (newCol.pages[0].content.length > 0) {
        resResult.openedNames.push(idx);  // 在前端其实没用到这个
        resResult.searchResultNum += newCol.pages[0].content.length;
        resResult.data.push(newCol);
      }
    })
    res.send(resResult);
  }
})

//使用 nginx 反向代理 或 在本地调试：

const serverUrl = "https://nought.cn/api/zhihu/start"
axios.post(serverUrl, { name: "1" })
  .then(function (sr) {
    const serverRes = sr.data.ok;

    if (serverRes === "error") {
      console.log("server not run well");
      process.exit();
      throw new Error("server error");
    }
  })
  .catch(function (err) {
    console.log("server not response well");
  })

var server = app.listen(85, function () {
  let host = server.address().address;
  let port = server.address().port;
  let url = `http://localhost:${port.toString()}`;
  console.log(`\n打开浏览器，网址为 ${url}`);
  console.log("\n当不再使用时，直接关闭本软件即可，下次使用时请重新运行本软件");
  
  let c = require('child_process');
  c.exec(`start ${url}`);
});

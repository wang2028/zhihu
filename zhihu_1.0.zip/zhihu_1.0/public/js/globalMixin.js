// 共用混入：
Vue.mixin({
    methods: {
        showResponseTip: function (res) {
            if (res) {
                if (res.status >= 200 && res.status < 300) {
                    this.$message({
                        showClose: true,
                        message: res.data.message || "成功",
                        type: 'success'
                    });
                }
                else if (res.status >= 400 && res.status < 600) {
                    this.$message({
                        showClose: true,
                        message: res.data.message || "发生网络错误，请稍后再试或联系 wangxw-cn@qq.com",
                        type: 'error'
                    });
                }
            }
            else{
                this.$message({
                    showClose: true,
                    message: "发生未知错误，请稍后再试或联系 wangxw-cn@qq.com",
                    type: 'error'
                });
            }
        },
    },
    data: function () {
        return {
            isMobileEnd: document.body.clientWidth<768,
        }
    },
    filters: {
        timeStr: function (val) {
            return toTimeStr(val);
        }
    }
});


// 以下方法直接挂载到 window，方便全局调用，
// 如果不挂在 window，会报引用错误，
// 也就是虽然在其他文件中 import 引入了，但该函数并没有暴露出去，
// 仍是在本文件作用域中。
window.toDateObj = function (d) {
    // 可用于将（后端传来的）各种类型的时间统一为Date
    var res = null;
    if (typeof d === 'string' && d[0] === '2') {
        res = new Date(d);
    }
    else if (typeof d === 'object' && d.time && d.time.toString().length === 13) {
        res = new Date(d.time);
    }
    else if (typeof d === 'number') {
        if (d.toString().length < 13) {
            for (var i = 0; i < 13 - d.toString().length; i++) {
                d *= 10;
            }
        }
        res = new Date(d);
    }
    else {
        res = new Date();
        console.error("toDateObj 遇到了未知的日期（时间）数据：",d);
    }

    return res;
}
window.toDateStr = function (d) {
    // 返回 “2019-01-01” 格式的时间字符串
    d = toDateObj(d);
    return d.getFullYear() + "-" + ((d.getMonth() + 1) < 10 ? '0' : '') + (d.getMonth() + 1) + "-" + (d.getDate() < 10 ? '0' : '') + d.getDate();
}
window.toTimeOnlyStr = function (d) {
    // 返回 “2019-01-01 13:23:10” 格式的时间字符串
    d = toDateObj(d);
    return (d.getHours() < 10 ? '0' : '') + d.getHours() + ":" + (d.getMinutes() < 10 ? '0' : '') + d.getMinutes() + ":" + (d.getSeconds() < 10 ? '0' : '') + d.getSeconds();
}
window.toTimeStr = function (d) {
    return toDateStr(d) + " " + toTimeOnlyStr(d);
}

window.getUrlParams = function(url = "") {
    var curUrl = url || window.location.href;
    if (curUrl.lastIndexOf("?") != -1) {
        var paramStr = curUrl.slice(curUrl.lastIndexOf("?") + 1);
        var params = paramStr.split("&");
        var p = {};
        for (var i = 0, len = params.length; i < len; i++) {
            var equalSymbolPos = params[i].indexOf("=");
            p[params[i].slice(0, equalSymbolPos)] = params[i].slice(equalSymbolPos + 1);
        }
        return p;
    }
    else {
        return {};
    }
}

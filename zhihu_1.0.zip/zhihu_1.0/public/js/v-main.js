var EventCenter = new Vue();

Vue.component("subscribe", {
    template: "#subsc-tpl",
    methods: {
    }
})


new Vue({
    el: "#app",
    data: {
        sidebarOpen: false,
        cols: [],
        loaded: false,
        titles: [],
        kw: '',
        subscribing: true,
        openedNames: [],
        email: '',
        zhid: '',

        openingName: '0',
        searchResultNum: 0,
        isShowVipDialog: false,
        isShowVersionTip: false,

        vipInfo: {
            isVip: false,
            vipUntil: 0,
            vipHistory: [],
        },
        vipStr: "赞助一下",
        vip: {
            month: 0,
            email: "",
        }
    },
    mounted: function () {
        var me = this;
        axios.post("/api/data", [])
            .then(function (res) {
                me.parseData(res.data);
                me.loaded = true;
            })
            .catch(function (err) {
                me.$alert(err, '发生错误', {
                    confirmButtonText: '确定',
                    callback: action => {
                        
                    }
                });
                me.showResponseTip(err.response);
                console.error(err);
                me.loaded = true;
            })
        EventCenter.$on("copyThisUrl", function () {
            me.$copyText(window.location.href).then(function (e) {
                me.$message({
                    showClose: true,
                    message: "复制成功",
                    type: 'success'
                });
            }, function (e) {
                me.$message({
                    showClose: true,
                    message: "复制失败，请手动复制...",
                    type: 'error'
                });
            })
        });
    },
    watch: {
        kw: function (newV, oldV) {
            this.loaded = 'ing';
        }
    },
    methods: {
        switchSideBar: function () {
            this.sidebarOpen = !this.sidebarOpen;
        },

        subsc: function () {
            this.subscribing = true;
        },
        copyThisUrl: function () {
            EventCenter.$emit('copyThisUrl');
        },
        showVipDialog: function () {
            this.isShowVipDialog = true;
            this.openingName = '0';
        },
        submitVip: function () {
            var me = this;
            if (!me.vip.month) {
                me.$message({
                    showClose: true,
                    message: "请填写月份",
                    type: 'error'
                });
                return;
            }
            if (!me.vip.email) {
                me.$message({
                    showClose: true,
                    message: "请填写邮箱",
                    type: 'error'
                });
                return;
            }
            me.$confirm(`确认已为邮箱 ${me.vip.email} 付款了 ${me.vip.month * 5} 元？`, '确认', {
                confirmButtonText: '确认',
                cancelButtonText: '取消',
                type: 'info',
            }).then(() => {
                // 点击了确认
                axios.post("/api/openVip", me.vip)
                    .then(function (res) {
                        me.showResponseTip(res);
                        me.isShowVipDialog = false;
                    })
                    .catch(function (error) {
                        if (error.response) {
                            me.showResponseTip(error.response);
                            console.error(error);
                        }
                        else {
                            me.showResponseTip();
                        }
                    })
            }).catch(() => {
                // 点击了取消：


            });

        },
        parseData: function (data) {
            var me = this;
            for (var i = 0; i < data.length; i++) {
                var col = {
                    title: data[i].title,
                    url: data[i].url,
                    updateTime: data[i].updateTime,
                    content: [],
                };
                var contents = data[i].pages;
                for (var j = 0; j < contents.length; j++) {
                    var c = contents[j].content;
                    for (var k = 0; k < c.length; k++) {
                        var it = c[k];
                        // it.str = JSON.stringify(it).toLowerCase();
                        it.show = true;
                        col.content.push(it);
                    }
                }
                col.rightSize = col.content.length;
                me.cols.push(col);
            }
        },
        startSearch: function () {
            var me = this;
            var newV = me.kw.trim();
            if (me.loaded === false) {
                return;
            }

            me.loaded = false;

            me.openedNames = [];
            me.searchResultNum = 0;
            me.cols = [];
            if (newV !== "") {
                var keys = newV.split(/ +/);
                keys.forEach(function (ele, idx, arr) {
                    keys[idx] = ele.toLowerCase();
                });
                axios.post("/api/data", keys)
                    .then(function (res) {
                        me.parseData(res.data.data);
                        // me.openedNames = res.data.openedNames;
                        for (var i = 0; i < me.cols.length; i++){
                            me.openedNames.push(i);
                        }
                        me.searchResultNum = res.data.searchResultNum;
                        me.loaded = true;
                    })
                    .catch(function (err) {
                        me.showResponseTip(err.response);
                        console.error(err);
                        me.loaded = true;
                    })
            }
            else {
                axios.post("/api/data", [])
                    .then(function (res) {
                        me.parseData(res.data);
                        me.loaded = true;
                    })
                    .catch(function (err) {
                        me.showResponseTip(err.response);
                        console.error(err);
                        me.loaded = true;
                    })
            }
        }
    },
})


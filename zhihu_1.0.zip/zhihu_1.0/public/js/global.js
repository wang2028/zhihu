

window.toDateObj = function (d) {
    // 可用于将（后端传来的）各种类型的时间统一为Date
    var res = null;
    if (typeof d === 'string' && d[0] === '2') {
        res = new Date(d);
    }
    else if (typeof d === 'object' && d.time && d.time.toString().length === 13) {
        res = new Date(d.time);
    }
    else {
        console.error("toDateObj 遇到了未知的日期（时间）数据：", d);
    }
    if (res && res.getFullYear() === 2099) {
        // res = null;
    }
    return res;
}
window.toTimeStr = function (d) {
    // 返回 “2019-01-01 13:23:10” 格式的时间字符串
    if (typeof d !== 'object') {
        // console.error('toTimeStr 参数未知：',d);
        d = new Date(d);
    }
    return d.getFullYear() + "-" + ((d.getMonth() + 1) < 10 ? '0' : '') + (d.getMonth() + 1) + "-" + (d.getDate() < 10 ? '0' : '') + d.getDate() + " " + (d.getHours() < 10 ? '0' : '') + d.getHours() + ":" + (d.getMinutes() < 10 ? '0' : '') + d.getMinutes() + ":" + (d.getSeconds() < 10 ? '0' : '') + d.getSeconds();

}
window.toDateStr = function (d) {
    // 返回 “2019-01-01” 格式的时间字符串
    if (typeof d !== 'object') {
        // console.error('toTimeStr 参数未知：',d);
        d = new Date(d);
    }
    return d.getFullYear() + "-" + ((d.getMonth() + 1) < 10 ? '0' : '') + (d.getMonth() + 1) + "-" + (d.getDate() < 10 ? '0' : '') + d.getDate();

}
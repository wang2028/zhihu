const cheerio = require('cheerio');
const fs = require('fs');
const logger = require('./logger');
const axios = require('axios');
const utils = require("./utils");
// const { cpuUsage } = require('process');


axios.defaults.headers.get['Content-Type'] = 'text/html; charset=utf-8';
axios.defaults.headers.get['User-Agent'] = utils.userAgent.chrome;

async function getColUrl(thisPageUrl, existedResults = null) {
    let results = existedResults || [];
    await axios.get(thisPageUrl)
        .then(async function (res) {
            let $ = cheerio.load(res.data);
            let data = $("script#js-initialData").html();
            if (data === null) {
                logger.error(`未获取到主页收藏夹数据：${thisPageUrl}`)
                return null;
            }
            let r1 = /"ids"\s*?:\s*?(\[.*?])/;
            let aStr = "";

            data.replace(r1, function (str, idx, data) {
                aStr += str;
            })
            aStr = aStr.replace(r1, '$1');
            let as = aStr.split(/[\[\],]/);
            let curLen = results.length;
            for (let i = 0; i < as.length; i++) {
                as[i] = as[i].toString().trim();
                if (as[i] && as[i] != 'false' && as[i] != 'null') {
                    if (results.indexOf(as[i]) < 0) {
                        results.push(as[i]);
                    }
                }
            }

            // logger.info(`result:${results.length}\ncurLen:${curLen}\nas:${as}`)

            if (results.length == curLen) {
                // 说明当前页已无内容
                results = [];
                return;
            }
            else {
                let nextPage = 2;
                if (thisPageUrl.indexOf("?page=") != -1) {
                    nextPage = parseInt(thisPageUrl.slice(thisPageUrl.indexOf("?page=") + 6)) + 1;
                    let nextRes = await getColUrl(thisPageUrl.slice(0, thisPageUrl.indexOf("?page=")) + "?page=" + nextPage, results)
                    results = results.concat(nextRes);
                }
                else {
                    let nextRes = await getColUrl(thisPageUrl + "?page=" + nextPage, results)
                    results = results.concat(nextRes);
                }
            }
        })
        .catch(function (err) {
            logger.error("63: " + err);
            results = null;
        })
    return results;
}

let getAllColUrl = async function (userName) {
    let homeUrl = `https://www.zhihu.com/people/${userName}/collections`;
    let colUrls = [];
    let stop = false;
    let curPage = 1;
    while (stop === false) {
        let curFavLen = colUrls.length;
        await axios.get(`${homeUrl}?page=${curPage}`)
            .then(async function (res) {
                let $ = cheerio.load(res.data);
                let data = $("script#js-initialData").html();
                if (data === null) {
                    logger.error(`未获取到主页收藏夹数据：${homeUrl}`)
                    colUrls = null;
                    return;
                }
                let favlist = JSON.parse(data).initialState.entities.favlists;
                let favIdArr = Object.keys(favlist);
                favIdArr.map(function (val, idx, arr) {
                    return {
                        id: val,
                        title: favlist[val].title,
                        updateTime: favlist[val].updatedTime * 1000
                    }
                }).forEach(function (val, idx, arr) {
                    let exist = false;
                    for (let i = 0; i < colUrls.length; i++) {
                        if (colUrls[i].id === val.id) {
                            exist = true;
                            break;
                        }
                    }
                    if (exist === false) {
                        colUrls.push(val);
                    }
                })

            })
            .catch(function (err) {
                logger.error("63: " + err);
                colUrls = null;
            });
        if (colUrls.length === curFavLen) {
            // 说明这轮爬取未新增收藏夹，不需要继续下一页爬取
            stop = true;
        }
        else {
            curPage++;
        }
    }

    return colUrls;
}

let handleColData = async function (val, thisColId, idx, arr) {
    const c = val.content;
    // console.log(c);
    let thisItem = {
        author: c.author.name,
        id: c.id,
    }
    if (c.type === "answer") {
        thisItem.summary = c.excerpt.toString().replace(/\<.+?\>/g, "");
        let canSkip = false;
        if (c.updated_time * 1000 < newMeta.lastTime) {
            // 上次已爬取过
            for (let i = 0; i < newMeta.lastData.length; i++){
                if (newMeta.lastData[i].id && thisColId && newMeta.lastData[i].id.toString() === thisColId.toString()) {
                    for (let j = 0; j < newMeta.lastData[i].pages.length; j++) {
                        for (let k = 0; k < newMeta.lastData[i].pages[j].content.length; k++) {
                            if (newMeta.lastData[i].pages[j].content[k].id && newMeta.lastData[i].pages[j].content[k].id.toString() === c.id.toString()) {
                                thisItem = newMeta.lastData[i].pages[j].content[k];
                                canSkip = true;
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }
        if (canSkip !== true) {
            let questionUrl = c.question.url  // 问题的api的url，不能直接用
            let queId = questionUrl.slice(questionUrl.lastIndexOf('/') + 1);
            let answersUrl = c.url   // 回答的api的url
            let ansId = answersUrl.slice(answersUrl.lastIndexOf('/') + 1);
            thisItem.url = `https://www.zhihu.com/question/${queId}/answer/${ansId}`

            thisItem.item = c.question.title;

            logger.info(`正在读取全文内容：${thisItem.url}`)

            // 全文搜索：
            await axios.get(thisItem.url)
                .then(function (res) {
                    let $ = cheerio.load(res.data);
                    const answerContent = $("div.Card.AnswerCard .QuestionAnswer-content .ContentItem.AnswerItem .RichContent-inner").text();
                    thisItem.full = answerContent;

                })
                .catch(function (err) {
                    console.error("全文搜索遇到错误：", thisItem.url);
                    console.error(err)
                })
        }
        else {
            logger.info(`全文数据已存在，跳过：${thisItem.url}`)
        }
        
    }
    else if (c.type === "article") {
        thisItem.summary = c.excerpt_title.toString().replace(/\<.+?\>/g, "");
        let canSkip = false;
        if (c.updated * 1000 < newMeta.lastTime) {
            // 上次已爬取过
            for (let i = 0; i < newMeta.lastData.length; i++) {
                if (newMeta.lastData[i].id && thisColId && newMeta.lastData[i].id.toString() === thisColId.toString()) {
                    for (let j = 0; j < newMeta.lastData[i].pages.length; j++) {
                        for (let k = 0; k < newMeta.lastData[i].pages[j].content.length; k++){
                            if (newMeta.lastData[i].pages[j].content[k].id && newMeta.lastData[i].pages[j].content[k].id.toString() === c.id.toString()) {
                                thisItem = newMeta.lastData[i].pages[j].content[k];
                                canSkip = true;
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }
        if (canSkip !== true) {
            thisItem.url = c.url;
            thisItem.item = c.title;
            logger.info(`正在读取全文内容：${thisItem.url}`)
            await axios.get(thisItem.url)
                .then(function (res) {
                    let $ = cheerio.load(res.data);
                    const articleContent = $("div.Post-RichTextContainer").text();
                    thisItem.full = articleContent;
                })
                .catch(function (err) {
                    console.error("全文搜索遇到错误：", thisItem.url);
                    console.error(err)
                })
        }
        else {
            logger.info(`全文数据已存在，跳过：${thisItem.url}`)
        }
        
    }
    else {
        thisItem.summary = c.excerpt.toString().replace(/\<.+?\>/g, "");
        thisItem.url = c.url;
        thisItem.item = c.title;
    }

    // console.log("thisItem:", thisItem);
    return thisItem;
}

function write2html(name, email, allCollections) {
    let html = "exports.data = " + JSON.stringify(allCollections) + "; \n ";
    delete newMeta.lastData;
    html += "exports.meta = " + JSON.stringify(newMeta);

    fs.writeFile('./data.js', html, function (err) {
        if (err) {
            logger.error("数据写入错误");
        }
        console.log("\n数据已写入 data.js（请勿直接打开该文件）");
    });
}

async function genName(homeUrl) {
    // 只需传入自己的主页的网址，如：https://www.zhihu.com/people/wang-xiang-wei-93/activities
    let pos = homeUrl.indexOf("people/");
    if (pos == -1) {
        return false;
    }
    let name = homeUrl.slice(pos + 7);
    if (name.indexOf('/') != -1) {
        name = name.slice(0, name.indexOf('/'));
    }
    if (name.indexOf('?') != -1) {
        name = name.slice(0, name.indexOf('?'));
    }
    let userApiPrefix = 'https://www.zhihu.com/api/v4/members/';

    let nameRes = null;

    let serverRes = "";
    try {
        const server = "https://nought.cn/api/zhihu/start"
        const sr = await axios.post(server, { name: "1" });
        serverRes = sr.data.ok;
        logger.info("serverRes:", serverRes);
    }
    catch (e) {
        logger.error("server error: ", e);
    }
    if (serverRes === "error") {
        throw new Error("colUrlArr is null");
    }

    await axios.get(userApiPrefix + name)
        .then(function (res) {
            nameRes = res.data['url_token'];
            if (nameRes.toString().trim() !== name.toString().trim()) {
                nameRes = null;
            }
        }).catch(function (err) {
            nameRes = null;
            logger.error("axios 抓取 name 错误：" + err);
            throw new Error("axios 抓取 name 错误：" + err);
        })

    // let res = await superagent.set('User-Agent', uaChrome).get(userApiPrefix + name);        
    // name = res.body['url_token'];

    if (nameRes !== null) {
        return nameRes;
    }
    else {
        return false;
    }
}


let newMeta = {
    updateTime: Date.now(),
    updateColArr: [],
    lastTime: (new Date("2000-01-01")).getTime(),
    lastColArr: [],
}
const path = require('path');
try {
    let dataFilePath = path.resolve(__dirname, "../data.js")
    if (!fs.existsSync(dataFilePath)) {
        // fs.existsSync 用相对路径会出错，需要转为绝对路径
        fs.writeFileSync(dataFilePath, " ", {
            flag: "w+",
        })
        newMeta.lastData = [];
    }
    else {
        const zhihuData = require("../data");
        newMeta.lastTime = zhihuData.meta.updateTime;
        newMeta.lastData = zhihuData.data;
        for (let i = 0; i < newMeta.lastData.length; i++) {
            newMeta.lastColArr.push(newMeta.lastData[i].id);
        }
        logger.info(`上次更新：${logger.toTimeStr(new Date(newMeta.lastTime))} 更新了 ${newMeta.lastColArr.length} 个收藏夹`);
    }
}
catch (e) {
    logger.warn("加载 data.js 失败：", e);
}

let main = async function (homeUrl, email, callback) {
    let userName = await genName(homeUrl);
    if (userName === false) {
        callback({
            code: 403,
            msg: "未能获取到知乎数据，请检查输入的主页网址，或稍后再试，或联系 wangxw-cn@qq.com",
        });
        return;
    }
    else {
        callback({
            code: 200,
            name: userName,
        });
    }
    newMeta.updateTime = Date.now();
    let colUrlArr = await getAllColUrl(userName);
    if (colUrlArr === null) {
        logger.error(`发生错误：colUrlArr is null: ${email} ${userName}`);
        return;
    }
    let allCollections = [];
    try {
        // TODO: colUrlArr.length
        for (let i = 0; i < colUrlArr.length; i++) {
            const colDetailUrl = `https://www.zhihu.com/api/v4/collections/${colUrlArr[i].id}/items?offset=0&limit=20`

            // 如果该收藏夹最后更新时间早于上次爬取，则不获取
            let thisColChangeTime = colUrlArr[i].updateTime.toString();
            if (thisColChangeTime.length < 13) {
                for (let tmp = 0; tmp < (13 - thisColChangeTime.length); tmp++) {
                    thisColChangeTime += "0";
                }
            }
            if (parseInt(thisColChangeTime) < parseInt(newMeta.lastTime) && newMeta.lastColArr.indexOf(colUrlArr[i].id) >= 0) {
                logger.info(`(${i + 1}/${colUrlArr.length}) 收藏夹 [${colUrlArr[i].title}](${colDetailUrl}) 自上次更新后(${logger.toTimeStr(new Date(parseInt(thisColChangeTime)))})未发生改变，已跳过`)
                // 将上次的内容直接推入新的数组
                for (let tmp = 0; tmp < newMeta.lastData.length; tmp++) {
                    if (newMeta.lastData[tmp].id.toString() === colUrlArr[i].id) {
                        allCollections.push(newMeta.lastData[tmp]);
                    }
                    thisColChangeTime += "0";
                }
                continue;
            }

            await utils.sleep(1000);
            logger.info(`(${i + 1}/${colUrlArr.length}) 正在读取收藏夹 [${colUrlArr[i].title}](${colDetailUrl})`)

            await axios.get(colDetailUrl)
                .then(async function (res) {
                    // console.log(res);
                    const data = res.data;
                    const colInfo = {
                        id: colUrlArr[i].id.toString(),
                        total: data.paging.totals,
                        title: colUrlArr[i].title,
                        url: "https://www.zhihu.com/collection/" + colUrlArr[i].id,
                        pages: [{
                            content: [],
                        }],
                        updateTime: colUrlArr[i].updateTime,
                    }
                    for (let k = 0; k < data.data.length; k++) {
                        const item = await handleColData(data.data[k], colInfo.id);
                        colInfo.pages[0].content.push(item);
                    }
                    if (colInfo.total > 20) {
                        let spyTime = (colInfo.total - 20) / 20 + 1;
                        for (let j = 0; j < spyTime; j++) {
                            await utils.sleep(10);

                            const extraiDetailUrl = `https://www.zhihu.com/api/v4/collections/${colUrlArr[i].id}/items?offset=${(j + 1) * 20}&limit=20`
                            await axios.get(extraiDetailUrl)
                                .then(async function (res2) {
                                    const data2 = res2.data;
                                    for (let l = 0; l < data2.data.length; l++) {
                                        const item = await handleColData(data2.data[l], colInfo.id);
                                        colInfo.pages[0].content.push(item);
                                    }
                                })
                                .catch(function (err) {
                                    logger.error(`285: ${err}`);
                                })
                        }
                    }
                    // console.log(colInfo.pages[0].content.length);
                    allCollections.push(colInfo);
                })
                .catch(function (err) {
                    logger.error("line 402: " + err);
                    throw new Error("axios 获取知乎数据 name 错误：" + err);
                })
            newMeta.updateColArr.push(colUrlArr[i].id.toString());
        }
        write2html(userName, email, allCollections);
    }
    catch (e) {
        logger.error("捕获严重错误，程序即将退出，现有数据即将保存：", e);
        if (newMeta.lastData && newMeta.lastData.length > 0 && allCollections.length === 0) {
            // ...
        }
        else {
            write2html(userName, email, allCollections);
        }
    }

}

exports.start = main;
exports.checkName = genName;

// main("wang-xiang-wei-93");

function toTimeStr(t) {
    let d = new Date();
    if (t) {
        d = t;
    }
    return d.getFullYear() + "-" + ((d.getMonth() + 1) < 10 ? '0' : '') + (d.getMonth() + 1) + "-" + (d.getDate() < 10 ? '0' : '') + d.getDate() + " " + (d.getHours() < 10 ? '0' : '') + d.getHours() + ":" + (d.getMinutes() < 10 ? '0' : '') + d.getMinutes() + ":" + (d.getSeconds() < 10 ? '0' : '') + d.getSeconds()
}

exports.toTimeStr = toTimeStr;

exports.time = function (t) {
    if (t) {
        return toTimeStr(new Date(t));
    }
    else {
        return toTimeStr();
    }
}

let getStackTrace = function () {
    let obj = {};
    Error.captureStackTrace(obj, getStackTrace);
    return obj.stack;
};

/**
 * type: INFO/ERROR/WARN
 */
let myLog = function (msgArr, type) {
    let stack = getStackTrace() || ""
    let matchResult = stack.match(/\(.*?\)/g) || []

    let line = matchResult[2] || ""
    let resStr = `${toTimeStr()} ${type} ${line.replace("(", "").replace(")", "")}`

    for (let i in msgArr) {
        if (typeof msgArr[i] == 'object') {
            msgArr[i] = JSON.stringify(msgArr[i])
        }
        resStr += " " + msgArr[i]
    }

    return resStr;
}
exports.info = function () {
    console.log(myLog(arguments, "INFO"))
}
exports.error = function () {
    console.error(myLog(arguments, "ERROR"))
}
exports.warn = function () {
    console.warn(myLog(arguments, "WARN"))
}

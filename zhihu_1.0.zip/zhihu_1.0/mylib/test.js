

// 未用的库："@shd101wyy/mume": "^0.3.3",

// const fs = require('fs');
// let html = "exports.data = " + JSON.stringify(data) + ";";
// html += "\n\n";
// html += "aaa";


// fs.writeFile('./data.js', html, function (err) {
//     if (err) {
//         console.error("数据写入错误");
//     }
//     console.log("数据已写入 data.js（请勿直接打开该文件）");
// });

const fs = require('fs')
const path = require('path')
let p = path.resolve(__dirname, "../data.js")
console.log(p);
console.log(fs.existsSync(p, fs.constants.F_OK))
